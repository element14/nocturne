History
=======

0.3.2
----------------

- todo escaping fix

0.3.1
----------------

- support for todos in api documentation
- access log improvements

0.3
----------------

- upstream server proxy (proxy an existing api)
- variables in url path
- simple api documentation (markdown)
- api authentication (HTTP Basic authentication)
- manage interface improvements

No notes on earlier releases.
