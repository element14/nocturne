tests Package
=============

:mod:`all` Module
-----------------

.. automodule:: mock_server.tests.all
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`test_restapi` Module
--------------------------

.. automodule:: mock_server.tests.test_restapi
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`test_xmlrpc` Module
-------------------------

.. automodule:: mock_server.tests.test_xmlrpc
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`upstream_server` Module
-----------------------------

.. automodule:: mock_server.tests.upstream_server
    :members:
    :undoc-members:
    :show-inheritance:

